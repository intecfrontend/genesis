function myFunction() {
var x = document.getElementById("myText").value;
document.getElementById("demo").innerHTML = x;
}